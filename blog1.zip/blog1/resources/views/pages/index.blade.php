@extends('layouts.app')

    @section('content')
    <div class="jumbotron"> 
        <h1>{{$title}}</h1>
        <p>Developed by Nwadinobi Chikeziem Okechi (2348164993630)</p>
        <p>
        <button type="button" class="btn btn-primary" href="/login">Login</button>
        <button type="button" class="btn btn-success" href="register">Register</button>
        </p>
    </div>
    @endsection
