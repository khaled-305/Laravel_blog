<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
  <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-link" href="/blog1/public/">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/blog1/public/services">Services</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/blog1/public/about">About Us</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/blog1/public/posts">Blog Posts</a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="/blog1/public/posts/create"> Create New Posts</a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="{{ url('/login') }}">Login</a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="{{ url('/register') }}">Register</a>
    </li>

    
  </ul>
</nav>

 <!-- Authentication Links -->
 @if (Auth::guest())
        <li><a href="{{ url('/login') }}">Login</a></li>
       <li><a href="{{ url('/register') }}">Register</a></li>
    @else
       <li class="dropdown">
       <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">  
        {{ Auth::user()->name }} <span class="caret"></span>
        </a>

         <ul class="dropdown-menu" role="menu">
         <li><a href="{{ url('/logout') }}">
         <i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
          </ul>
         </li>
    @endif