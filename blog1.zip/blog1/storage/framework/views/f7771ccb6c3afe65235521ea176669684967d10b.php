    <?php $__env->startSection('content'); ?>
    <div class="jumbotron"> 
        <h1><?php echo e($title); ?></h1>
        <p>Developed by Nwadinobi Chikeziem Okechi (2348164993630)</p>
        <p>
        <button type="button" class="btn btn-primary" href="/login">Login</button>
        <button type="button" class="btn btn-success" href="register">Register</button>
        </p>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>