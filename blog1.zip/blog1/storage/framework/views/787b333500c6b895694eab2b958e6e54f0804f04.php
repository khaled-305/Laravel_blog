    <?php $__env->startSection('content'); ?>
      <h1><?php echo e($title); ?></h1>
          <?php if(count($services) > 0): ?>
          <ul class="list-group">
             <?php foreach($services as $service): ?>
             <li class="list-group-item"><?php echo e($service); ?></li>
             <?php endforeach; ?>
          </ul>
          <?php endif; ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>