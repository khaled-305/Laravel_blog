<?php $__env->startSection('content'); ?>
<h1> Recent Posts </h1>

   <?php if(count($posts) > 0): ?>

   <?php foreach($posts as $post): ?>

   <div class="card card-body bg-light">

   <h3><a href="/blog1/public/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h3>
   <small><a href="/blog1/public/posts/<?php echo e($post->id); ?>">Written on: <?php echo e($post->created_at); ?></a></small>
   
   </div>

   <?php endforeach; ?>
    <?php echo e($posts->links()); ?>

   <?php else: ?>
    <p> No Posts found!!</p>
   <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>