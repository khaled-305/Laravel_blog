<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
 /*
Route::get('/', 'PagesController@index');
Route::get('/about', 'PagesController@about');
*/

Route::get('/', function () {
    $title = 'Welcome to My Awsome Laravel Blog!!';
    return view('pages.index')->with('title', $title);
});

Route::get('/about', function () {
    $title = 'About Us';
    return view('pages.about')->with('title', $title);
});

Route::get('/services', function () {
    $data = array(
        'title' => 'Our Services',
        'services' => ['Web Designs', 'App development', 'Graphics']
    );
    return view('pages.services')->with($data);
});

Route::resource('posts', 'PostsController');
Route::auth();

Route::get('/home', 'HomeController@index');
